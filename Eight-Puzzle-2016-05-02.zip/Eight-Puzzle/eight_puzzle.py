import wx
import time
import random
class MyApp(wx.App):
    def OnInit(self):
        self.frame=MainFrame(None,title='Eight-Puzzle',size=(764,636))
        self.SetTopWindow(self.frame)
        self.frame.Centre()
        #time.sleep(5)
        self.frame.Show(True)
        return True

### Main Frame Class -==========================================================
class MainFrame(wx.Frame):
    def __init__(self,*arg,**kwarg):
        wx.Frame.__init__(self,*arg,**kwarg)
        panel=wx.Panel(self,-1)
        grid=wx.GridSizer(rows=3,cols=3,vgap=5,hgap=5)

        self.ls_ig=[]
        for i in range(9):
            img=wx.StaticBitmap(panel,100+i,size=(250,200))
            #img.SetBitmap()
            self.ls_ig.append((img,0,15,15))
        #self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/01.png'))
        #Initial SetUp
        c=0
        for i in range(1,4):
            s='images/0'+str(i)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1

            s='images/0'+str(i+3)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1

            s='images/0'+str(i+6)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1
        #Initial SetUp End
        #grid.Add()
        grid.AddMany(self.ls_ig)
        #time.sleep(2)
        #print 'sizeof self.ls_ig',len(self.ls_ig)
        #print self.ls_ig[0][0].GetId()
        #Random Arrangement
        """self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/09.png'))
        self.ls_ig[8][0].SetBitmap(wx.Bitmap('images/01.png'))
        rs=[2,3,4,5,6,7,8]
        for i in range(1,8):
            e=random.choice(rs)
            self.ls_ig[i][0].SetBitmap(wx.Bitmap('images/0'+str(e)+'.png'))
            rs.remove(e)"""
        self.blank=8
        self.imap=['']*9
        #wx.Bell()
        wx.FutureCall(1200,self.setRandom)
        panel.SetSizer(grid)
        self.Bind(wx.EVT_KEY_DOWN,self.onKeyPress)
    def setRandom(self):
        self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/09.png'))
        self.ls_ig[8][0].SetBitmap(wx.Bitmap('images/01.png'))
        self.imap[0]='09.png'
        self.imap[8]='01.png'
        rs=[2,3,4,5,6,7,8]
        for i in range(1,8):
            e=random.choice(rs)
            self.ls_ig[i][0].SetBitmap(wx.Bitmap('images/0'+str(e)+'.png'))
            self.imap[i]='0'+str(e)+'.png'
            rs.remove(e)
    def onKeyPress(self,e):
        #print 'Key is Pressed'
        kc=e.GetKeyCode()
        if kc==wx.WXK_UP:
            target=self.blank-3

        elif kc==wx.WXK_DOWN:
            target=self.blank+3

        elif kc==wx.WXK_LEFT:
            if self.blank==3 or self.blank==6:
                target=-1
            else:
                target=self.blank-1

        elif kc==wx.WXK_RIGHT:
            if self.blank==2 or self.blank==5:
                target=-1
            else:
                target=self.blank+1
         #Now Handle the Situation
        if target<0 or target>8:
                wx.Bell()
        else:
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            self.blank=target


### Another Classes -===========================================================


### Main Thread -===============================================================
app=MyApp()
app.MainLoop()
