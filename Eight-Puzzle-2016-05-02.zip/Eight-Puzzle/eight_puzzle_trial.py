#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      shubham
#
# Created:     11-10-2014
# Copyright:   (c) shubham 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import wx
import time
import random
class MyApp(wx.App):
    def OnInit(self):
        self.frame=MainFrame(None,title='Eight-Puzzle',size=(764,636))
        self.SetTopWindow(self.frame)
        self.frame.Centre()
        #time.sleep(5)
        self.frame.Show(True)
        return True

### Main Frame Class -==========================================================
class MainFrame(wx.Frame):
    def __init__(self,*arg,**kwarg):
        wx.Frame.__init__(self,*arg,**kwarg)
        panel=wx.Panel(self,-1)
        grid=wx.GridSizer(rows=3,cols=3,vgap=5,hgap=5)

        self.ls_ig=[]
        for i in range(9):
            img=wx.StaticBitmap(panel,100+i,size=(250,200))
            #img.SetBitmap()
            self.ls_ig.append((img,0,15,15))
        #self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/01.png'))
        #Initial SetUp
        c=0
        for i in range(1,4):
            s='images/0'+str(i)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1

            s='images/0'+str(i+3)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1

            s='images/0'+str(i+6)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1
        #Initial SetUp End
        #grid.Add()
        grid.AddMany(self.ls_ig)
        #time.sleep(2)
        #print 'sizeof self.ls_ig',len(self.ls_ig)
        #print self.ls_ig[0][0].GetId()
        #Random Arrangement
        """self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/09.png'))
        self.ls_ig[8][0].SetBitmap(wx.Bitmap('images/01.png'))
        rs=[2,3,4,5,6,7,8]
        for i in range(1,8):
            e=random.choice(rs)
            self.ls_ig[i][0].SetBitmap(wx.Bitmap('images/0'+str(e)+'.png'))
            rs.remove(e)"""
        self.blank=8
        self.imap=['']*9
        self.goal=['01.png','04.png','07.png','02.png','05.png','08.png','03.png','06.png','09.png']
        #wx.Bell()
        wx.FutureCall(1200,self.setRandom)
        #self.setRandom()
        panel.SetSizer(grid)
        self.Bind(wx.EVT_KEY_DOWN,self.onKeyPress)
        #self.heu1()
        #wx.FutureCall(3000,self.heu1)

    def heu1(self):
        #Heuristic for No of misplaced tiles
        print 'Bot-1 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=10
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=100
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu1(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h

    def computeHeu1(self,temp):
        ans=0
        #print 'This is Heuristic Computation'
        #print self.goal
        #print temp
        for i in range(9):
            if self.goal[i]!=temp[i]:
                ans+=1
        #print ans
        return ans

    def gen(self,blank):
        if blank==0:
            return [1,3]
        elif blank==1:
            return [0,2,4]
        elif blank==2:
            return [1,5]
        elif blank==3:
            return [0,4,6]
        elif blank==4:
            return [1,3,5,7]
        elif blank==5:
            return [2,4,8]
        elif blank==6:
            return [3,7]
        elif blank==7:
            return [4,6,8]
        elif blank==8:
            return [5,7]


    def setRandom(self):
        self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/09.png'))
        self.ls_ig[8][0].SetBitmap(wx.Bitmap('images/01.png'))
        self.imap[0]='09.png'
        self.imap[8]='01.png'
        rs=[2,3,4,5,6,7,8]
        for i in range(1,8):
            e=random.choice(rs)
            self.ls_ig[i][0].SetBitmap(wx.Bitmap('images/0'+str(e)+'.png'))
            self.imap[i]='0'+str(e)+'.png'
            rs.remove(e)

    def onKeyPress(self,e):
        #print 'Key is Pressed'
        kc=e.GetKeyCode()
        if kc==wx.WXK_UP:
            target=self.blank-3

        elif kc==wx.WXK_DOWN:
            target=self.blank+3

        elif kc==wx.WXK_LEFT:
            if self.blank==3 or self.blank==6:
                target=-1
            else:
                target=self.blank-1

        elif kc==wx.WXK_RIGHT:
            if self.blank==2 or self.blank==5:
                target=-1
            else:
                target=self.blank+1
         #Now Handle the Situation
        if target<0 or target>8:
                wx.Bell()
        else:
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            self.blank=target


### Another Classes -===========================================================


### Main Thread -===============================================================
app=MyApp()
app.MainLoop()
