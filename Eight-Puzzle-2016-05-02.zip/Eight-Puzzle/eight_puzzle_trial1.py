#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:     Analysis of heuristics
#
# Author:      shubham
#
# Created:     11-10-2014
# Copyright:   (c) shubham 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import wx
import time
import random
class MyApp(wx.App):
    def OnInit(self):
        self.frame=MainFrame(None,title='Eight-Puzzle',size=(764,636))
        self.SetTopWindow(self.frame)
        self.frame.Centre()
        #time.sleep(5)
        self.frame.Show(True)
        return True

### Main Frame Class -==========================================================
class MainFrame(wx.Frame):
    def __init__(self,*arg,**kwarg):
        wx.Frame.__init__(self,*arg,**kwarg)
        panel=wx.Panel(self,-1)
        grid=wx.GridSizer(rows=3,cols=3,vgap=5,hgap=5)

        self.ls_ig=[]
        for i in range(9):
            img=wx.StaticBitmap(panel,100+i,size=(250,200))
            #img.SetBitmap()
            self.ls_ig.append((img,0,15,15))
        #self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/01.png'))
        #Initial SetUp
        c=0
        for i in range(1,4):
            s='images/0'+str(i)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1

            s='images/0'+str(i+3)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1

            s='images/0'+str(i+6)+'.png'
            self.ls_ig[c][0].SetBitmap(wx.Bitmap(s))
            c+=1
        #Initial SetUp End
        #grid.Add()
        grid.AddMany(self.ls_ig)
        #time.sleep(2)
        #print 'sizeof self.ls_ig',len(self.ls_ig)
        #print self.ls_ig[0][0].GetId()
        #Random Arrangement
        """self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/09.png'))
        self.ls_ig[8][0].SetBitmap(wx.Bitmap('images/01.png'))
        rs=[2,3,4,5,6,7,8]
        for i in range(1,8):
            e=random.choice(rs)
            self.ls_ig[i][0].SetBitmap(wx.Bitmap('images/0'+str(e)+'.png'))
            rs.remove(e)"""
        self.blank=0
        self.imap=['']*9
        self.goal=['01.png','04.png','07.png','02.png','05.png','08.png','03.png','06.png','09.png']
        #wx.Bell()
        #wx.FutureCall(400,self.setRandom)
        #time.sleep(.5)
        self.setRandom()
        panel.SetSizer(grid)
        self.Bind(wx.EVT_KEY_DOWN,self.onKeyPress)
        #self.heu1()
        #wx.FutureCall(3000,self.heu6)
        #wx.FutureCall(3000,self.computeHeu4,self.imap)
        dial=MainDial(self,-1,'MainFrame')
        dial.ShowModal()
        dial.Destroy()


    def heu1(self):
        #Heuristic for No of misplaced tiles
        print 'Bot-1 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=10
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=100
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu1(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h

    def computeHeu1(self,temp):
        ans=0
        #print 'This is Heuristic Computation'
        #print self.goal
        #print temp
        for i in range(9):
            if self.goal[i]!=temp[i]:
                ans+=1
        #print ans
        return ans
    def heu2(self):
        #Heuristic for Manhatton Distance
        print 'Bot-2 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=100
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=100
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu2(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h

    def computeHeu2(self,temp):
        ans=0
        #print self.goal
        #print temp
        map_cord=[(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
        h=0
        v=0
        for i in range(9):
            cord1=map_cord[i]
            cord2=map_cord[self.goal.index(temp[i])]
            #print cord1,cord2,abs(cord1[0]-cord2[0]),abs(cord1[1]-cord2[1])
            h=h+abs(cord1[1]-cord2[1])
            v=v+abs(cord1[0]-cord2[0])
        ans=h+v
        return ans
    def heu3(self):
        #Heuristic for Euclidean Distance
        print 'Bot-3 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=100
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=100
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu3(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h

    def computeHeu3(self,temp):
        ans=0
        #print self.goal
        #print temp
        map_cord=[(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
        h=0
        v=0
        for i in range(9):
            cord1=map_cord[i]
            cord2=map_cord[self.goal.index(temp[i])]
            #print cord1,cord2,abs(cord1[0]-cord2[0]),abs(cord1[1]-cord2[1])
            h=h+abs(cord1[1]-cord2[1])
            v=v+abs(cord1[0]-cord2[0])
        ans=(h*h+v*v)**0.5
        return ans
    def heu4(self):
        #Heuristic for misplaced row and collumn
        print 'Bot-4 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=100
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=100
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu4(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h

    def computeHeu4(self,temp):
        ans=0
        #print self.goal
        #print temp
        map_cord=[(0,0),(0,1),(0,2),(1,0),(1,1),(1,2),(2,0),(2,1),(2,2)]
        for i in range(9):
            cord1=map_cord[i]
            cord2=map_cord[self.goal.index(temp[i])]
            #print cord1,cord2
            ans+=(cord1[0]!=cord2[0])
            ans+=(cord1[1]!=cord2[1])
        #print ans

        return ans
    def heu5(self):
        #heu2+heu3
        print 'Bot-5 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=100
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=1000
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu2(temp)+self.computeHeu3(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h

    def heu6(self):
        #heu1+heu2+heu3+heu4
        print 'Bot-5 Start Now'
        counter=0
        check_list=[]
        print self.imap
        best_h=100
        while self.imap!=self.goal:
            time.sleep(0.020)
            counter+=1
            print 'Hello Check',counter
            ts=self.gen(self.blank)
            h=1000
            target=-1
            #print 'ts',ts,'\n'
            for i in ts:
                temp=list(self.imap)
                #print 'check_list',check_list
                #print 'temp',temp
                #print
                temp[self.blank],temp[i]=temp[i],temp[self.blank]
                if temp not in check_list:
                    #temp[self.blank],temp[i]=temp[i],temp[self.blank]
                    h_temp=self.computeHeu2(temp)+self.computeHeu3(temp)+self.computeHeu1(temp)+self.computeHeu4(temp)
                    if h>=h_temp:
                        print 'Heuristic',h_temp
                        h=h_temp
                        target=i
                        if best_h>h:
                            best_h=h

            if target==-1:
                print 'Got Stuck! Pleae Reaboot'
                break
            #Now make move
            checked=list(self.imap)
            check_list.append(checked)
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            #check_list.append(self.imap)
            self.blank=target
            #print
            #print
        print 'Best Heuristic',best_h


    def gen(self,blank):
        if blank==0:
            return [1,3]
        elif blank==1:
            return [0,2,4]
        elif blank==2:
            return [1,5]
        elif blank==3:
            return [0,4,6]
        elif blank==4:
            return [1,3,5,7]
        elif blank==5:
            return [2,4,8]
        elif blank==6:
            return [3,7]
        elif blank==7:
            return [4,6,8]
        elif blank==8:
            return [5,7]


    def setRandom(self):
        self.ls_ig[0][0].SetBitmap(wx.Bitmap('images/01.png'))
        #self.ls_ig[8][0].SetBitmap(wx.Bitmap('images/01.png'))
        self.imap[0]='01.png'
        #self.imap[8]='01.png'
        rs=[2,3,4,5,6,7,8,9]
        for i in range(1,9):
            e=random.choice(rs)
            self.ls_ig[i][0].SetBitmap(wx.Bitmap('images/0'+str(e)+'.png'))
            self.imap[i]='0'+str(e)+'.png'
            rs.remove(e)

    def onKeyPress(self,e):
        #print 'Key is Pressed'
        kc=e.GetKeyCode()
        if kc==wx.WXK_UP:
            target=self.blank-3

        elif kc==wx.WXK_DOWN:
            target=self.blank+3

        elif kc==wx.WXK_LEFT:
            if self.blank==3 or self.blank==6:
                target=-1
            else:
                target=self.blank-1

        elif kc==wx.WXK_RIGHT:
            if self.blank==2 or self.blank==5:
                target=-1
            else:
                target=self.blank+1
         #Now Handle the Situation
        if target<0 or target>8:
                wx.Bell()
        else:
            timg=self.imap[target]
            timg='images/'+timg
            self.ls_ig[self.blank][0].SetBitmap(wx.Bitmap(timg))
            self.ls_ig[target][0].SetBitmap(wx.Bitmap('images/01.png'))
            self.imap[self.blank],self.imap[target]=self.imap[target],self.imap[self.blank]
            self.blank=target


### Another Classes -===========================================================
class MainDial(wx.Dialog):
    def __init__(self,parent,id,title):
        wx.Dialog.__init__(self,parent,id,title,pos=(10,10),size=(300,330))
        players=['human','bot-1','bot-2','bot-3','bot-4','bot-5','bot-6']
        st1=wx.StaticText(self,-1,'Select',pos=(100,20))
        cb=wx.ComboBox(self, -1, pos=(100, 40), size=(150, -1), choices=players,style=wx.CB_READONLY)
        self.idx=-1
        self.Bind(wx.EVT_COMBOBOX,self.onSelect)
        btn1=wx.Button(self,500,'Start',pos=(100,70))
        self.Bind(wx.EVT_BUTTON,self.onStart,id=500)
        wx.StaticLine(self,-1,(10,100),(290,1))
        btn2=wx.Button(self,501,'Best Scores',pos=(100,120))
        btn3=wx.Button(self,502,'Portfolio',pos=(100,150))
        btn4=wx.Button(self,503,'About',pos=(100,180))
        st2=wx.StaticText(self,-1,'Press (O) to Pop-Up this window again!',pos=(10,260))
        self.Bind(wx.EVT_BUTTON,self.onBest,id=501)
        self.Bind(wx.EVT_BUTTON,self.onDetail,id=502)
        self.Bind(wx.EVT_BUTTON,self.onAbout,id=503)
    def onBest(self,e):
        pass
    def onDetail(self,e):
        pass
    def onAbout(self,e):
        desc='''
                   This Software is an effort to analyze the  various  heuristic
                   functions to slove the eight puzzle problem.There is a option
                   for human to slove the eight-puzzle problem.In this  software
                   there are many heuristic are used.Some of them  are different
                   and some is obtained from the combination of the others.
                   The heuristic are...
                   1. Number of misplaced tiles
                   2. Manhatton Distance
                   3. Euclidean Distance
                   4. Number of misplaced collumn and rows
                   5. Combination of 2 and 3
                   6. Combination of 1,2,3 and 4
        '''
        lcs="Open Distrbution"
        info=wx.AboutDialogInfo()
        info.SetIcon(wx.Icon('images/logo2.jpg',wx.BITMAP_TYPE_JPEG))
        info.SetName('Eight-Puzzle')
        info.SetVersion('1.0')
        info.SetDescription(desc)
        info.SetCopyright('(C) 2014 Shubham Chaudhary')
        info.SetLicence(lcs)
        info.AddDeveloper('Shubham Chaudhary')
        info.AddDocWriter('Shubham Chaudhary')
        wx.AboutBox(info)
    def onSelect(self,e):
        self.idx=e.GetSelection()
        #print self.idx
    def onStart(self,e):
        #print 'Start with',self.idx
        p=self.GetParent()
        self.Close()
        #p.heu1()
        #wx.FutureCall(10,p.heu2)
        if self.idx==0:
            self.Close()
        elif self.idx==1:
            self.Close()
            wx.FutureCall(10,p.heu1)
        elif self.idx==2:
            self.Close()
            wx.FutureCall(10,p.heu2)
        elif self.idx==3:
            self.Close()
            wx.FutureCall(10,p.heu3)
        elif self.idx==4:
            self.Close()
            wx.FutureCall(10,p.heu4)
        elif self.idx==5:
            self.Close()
            wx.FutureCall(10,p.heu5)
        elif self.idx==6:
            self.Close()
            wx.FutureCall(10,p.heu6)


### Main Thread -===============================================================
app=MyApp()
app.MainLoop()
