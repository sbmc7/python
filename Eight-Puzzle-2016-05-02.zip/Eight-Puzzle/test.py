#File handling
f=open('config/temp.txt','r')
l1=f.readlines()
f.close()
temp=[]
for i in l1:
    l=map(int,i.split())
    temp.append(l)
for i in temp:
    print i

print 'perm file'
perm=[]
f=open('config/perm.txt','r')
l1=f.readlines()
f.close()
for i in l1:
    l=map(int,i.split())
    perm.append(l)
for i in perm:
    print i
#End of File handling
